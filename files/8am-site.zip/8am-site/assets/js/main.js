/* 8:AM — интерактив */
(function () {
  'use strict';

  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Хедер: фон при скролле ---------- */
  var hdr = document.getElementById('hdr');
  var lastY = window.scrollY;

  function onScroll() {
    var y = window.scrollY;
    hdr.classList.toggle('is-scrolled', y > 24);
    lastY = y;
  }
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  /* ---------- Мобильное меню ---------- */
  var burger = document.querySelector('.burger');
  var mnav = document.getElementById('mobile-nav');
  var mnavOpen = false;

  function setScrollLock(lock) {
    document.body.style.overflow = lock ? 'hidden' : '';
  }

  function openMnav() {
    mnavOpen = true;
    mnav.hidden = false;
    requestAnimationFrame(function () { mnav.classList.add('is-open'); });
    burger.setAttribute('aria-expanded', 'true');
    burger.setAttribute('aria-label', 'Закрыть меню');
    setScrollLock(true);
  }

  function closeMnav() {
    mnavOpen = false;
    mnav.classList.remove('is-open');
    burger.setAttribute('aria-expanded', 'false');
    burger.setAttribute('aria-label', 'Открыть меню');
    setScrollLock(false);
    window.setTimeout(function () {
      if (!mnavOpen) mnav.hidden = true;
    }, 380);
  }

  burger.addEventListener('click', function () {
    mnavOpen ? closeMnav() : openMnav();
  });

  mnav.addEventListener('click', function (e) {
    if (e.target.closest('a')) closeMnav();
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && mnavOpen) closeMnav();
  });

  /* ---------- Статус «открыто / закрыто» ---------- */
  var OPEN_H = 8;
  var CLOSE_H = 22;

  function pad(n) { return (n < 10 ? '0' : '') + n; }

  function setStatus() {
    var now = new Date();
    var h = now.getHours() + now.getMinutes() / 60;
    var isOpen = h >= OPEN_H && h < CLOSE_H;
    var text = isOpen
      ? 'Открыто · до ' + CLOSE_H + ':00'
      : 'Закрыто · откроемся в ' + pad(OPEN_H) + ':00';

    document.querySelectorAll('[data-open-status]').forEach(function (el) {
      el.textContent = text;
      el.classList.toggle('is-closed', !isOpen);
    });
  }
  setStatus();
  window.setInterval(setStatus, 60000);

  /* ---------- Табы меню ---------- */
  var tablist = document.querySelector('.tabs');

  if (tablist) {
    var tabs = Array.prototype.slice.call(tablist.querySelectorAll('.tab'));

    function selectTab(tab, focus) {
      tabs.forEach(function (t) {
        var selected = t === tab;
        t.classList.toggle('is-active', selected);
        t.setAttribute('aria-selected', selected ? 'true' : 'false');
        t.setAttribute('tabindex', selected ? '0' : '-1');

        var panel = document.getElementById(t.getAttribute('aria-controls'));
        if (!panel) return;
        if (selected) {
          panel.hidden = false;
          panel.classList.add('is-active');
        } else {
          panel.hidden = true;
          panel.classList.remove('is-active');
        }
      });
      if (focus) tab.focus();
    }

    tablist.addEventListener('click', function (e) {
      var tab = e.target.closest('.tab');
      if (tab) selectTab(tab, false);
    });

    tablist.addEventListener('keydown', function (e) {
      var i = tabs.indexOf(document.activeElement);
      if (i === -1) return;
      var next = null;

      if (e.key === 'ArrowDown' || e.key === 'ArrowRight') next = tabs[(i + 1) % tabs.length];
      else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') next = tabs[(i - 1 + tabs.length) % tabs.length];
      else if (e.key === 'Home') next = tabs[0];
      else if (e.key === 'End') next = tabs[tabs.length - 1];

      if (next) {
        e.preventDefault();
        selectTab(next, true);
      }
    });
  }

  /* ---------- Появление блоков ---------- */
  var revealItems = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window && !reduced) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.14, rootMargin: '0px 0px -6% 0px' });

    revealItems.forEach(function (el) { io.observe(el); });
  } else {
    revealItems.forEach(function (el) { el.classList.add('is-in'); });
  }

  /* ---------- Первый кадр hero ---------- */
  var hero = document.querySelector('.hero');
  if (hero) {
    if (document.readyState === 'complete') hero.classList.add('is-loaded');
    else window.addEventListener('load', function () { hero.classList.add('is-loaded'); });
    setTimeout(function () { hero.classList.add('is-loaded'); }, 900);
  }

  /* ---------- Галерея / лайтбокс ---------- */
  var gallery = document.querySelector('[data-gallery]');
  var lb = document.getElementById('lightbox');

  if (gallery && lb) {
    var shots = Array.prototype.slice.call(gallery.querySelectorAll('.shot'));
    var lbImg = lb.querySelector('img');
    var lbCounter = lb.querySelector('.lb__counter');
    var lbClose = lb.querySelector('.lb__close');
    var current = 0;
    var lastFocus = null;

    function show(i) {
      current = (i + shots.length) % shots.length;
      var shot = shots[current];
      var full = shot.getAttribute('data-full');
      var inner = shot.querySelector('img');

      lbImg.src = full;
      lbImg.alt = inner ? inner.alt : '8:AM — фотография кофейни';
      lbCounter.textContent = pad(current + 1) + ' / ' + pad(shots.length);
    }

    function openLb(i) {
      lastFocus = document.activeElement;
      show(i);
      lb.hidden = false;
      requestAnimationFrame(function () { lb.classList.add('is-open'); });
      setScrollLock(true);
      lbClose.focus();
    }

    function closeLb() {
      lb.classList.remove('is-open');
      setScrollLock(false);
      window.setTimeout(function () { lb.hidden = true; }, 300);
      if (lastFocus) lastFocus.focus();
    }

    shots.forEach(function (shot, i) {
      shot.addEventListener('click', function () { openLb(i); });
    });

    lbClose.addEventListener('click', closeLb);

    lb.querySelector('.lb__nav--prev').addEventListener('click', function () { show(current - 1); });
    lb.querySelector('.lb__nav--next').addEventListener('click', function () { show(current + 1); });

    lb.addEventListener('click', function (e) {
      if (e.target === lb) closeLb();
    });

    document.addEventListener('keydown', function (e) {
      if (lb.hidden) return;
      if (e.key === 'Escape') closeLb();
      else if (e.key === 'ArrowLeft') show(current - 1);
      else if (e.key === 'ArrowRight') show(current + 1);
      else if (e.key === 'Tab') {
        // держим фокус внутри окна
        var focusable = lb.querySelectorAll('button');
        var first = focusable[0];
        var last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  }

  /* ---------- Год в подвале ---------- */
  var year = document.querySelector('[data-year]');
  if (year) year.textContent = new Date().getFullYear();
})();
